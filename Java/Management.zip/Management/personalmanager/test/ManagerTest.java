package Java.Management.personalmanager.test;


import Java.Management.personalmanager.frame.LoginFrame;

public class ManagerTest {

	public static void main(String[] args) {
		new LoginFrame();
	}
}
