package Java.Management;

import Java.Management.views.LoginView;
import Java.Management.views.MainView;
import com.sun.tools.javac.util.Convert;

import java.awt.*;
import java.util.Random;

/**
 * Created by Julis on 17/8/19.
 * User:Julis 落叶挽歌
 * Date:17/8/19
 * Time:下午2:11
 */
public class Main {
    public static void main(String []args){
        //new LoginView();
        new MainView();
    }

}
