/**
 * Created by Julis on 17/9/5.
 * User:Julis 落叶挽歌
 * Date:17/9/5
 * Time:下午10:35
 */
var myDate = new Date();
alert(myDate.getFullYear()
    +"-"+myDate.getMonth()
    +"-"+myDate.getDay()
    +" "+myDate.getHours()
    +":"+myDate.getMinutes()
    +":"+myDate.getSeconds()) ;